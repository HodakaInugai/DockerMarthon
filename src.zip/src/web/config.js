const config = {
  apiUrl: 'http://localhost:3324'
};

export default config;